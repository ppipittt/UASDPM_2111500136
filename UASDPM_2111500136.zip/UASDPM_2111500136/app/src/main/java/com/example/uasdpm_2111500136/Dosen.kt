package com.example.uasdpm_2111500136

class Dosen(
    var nidn: String,
    var nmDosen: String,
    var jabatan: String,
    var gol_pangkat: String,
    var pendidikan: String,
    var keahlian: String,
    var pstudi: String
)