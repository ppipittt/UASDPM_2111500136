package com.example.uasdpm_2111500136

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class EntriDosenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entri_dosen)

        val modeEdit = intent.hasExtra("nid") && intent.hasExtra("nama") &&
                intent.hasExtra("jabatan") && intent.hasExtra("gol_pangkat") &&
                intent.hasExtra("pendidikan") && intent.hasExtra("keahlian")
                && intent.hasExtra("program_studi")
        title = if(modeEdit) "Edit Data Dosen" else "Entri Data Dosen"

        val etNidn = findViewById<EditText>(R.id.etNidn)
        val etNmDosen = findViewById<EditText>(R.id.etNmDosen)
        val spnJabatan = findViewById<Spinner>(R.id.spnJabatan)
        val spnGolpangkat = findViewById<Spinner>(R.id.spnGolpangkat)
        val rdS2 = findViewById<RadioButton>(R.id.rdS2)
        val rdS3= findViewById<RadioButton>(R.id.rdS3)
        val etKeahlian = findViewById<EditText>(R.id.etKeahlian)
        val etPstudi = findViewById<EditText>(R.id.etPstudi)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)

        val jabatann = arrayOf("Tenaga Pengajar",
        "Asisten Ahli","Lektor","Lektor Kepala","Guru Besar")
        val gol_pangkat = arrayOf("III/a - Penata Muda","III/b - Penata Muda Tingkat I","III/c - Penata",
            "III/d - Penata Tingkat I", "IV/a - Pembina","IV/b - Pembina Tingkat I", "IV/c - Pembina Utama Muda",
            "IV/d - Pembina Utama Madya","IV/e - Pembina Utama")
        val adpjabatan = ArrayAdapter(
            this@EntriDosenActivity,
            android.R.layout.simple_spinner_dropdown_item,
            jabatann
        )
        spnJabatan.adapter = adpjabatan
        val adpgol_pangkat = ArrayAdapter(
            this@EntriDosenActivity,
            android.R.layout.simple_spinner_dropdown_item,
            gol_pangkat
        )
        spnGolpangkat.adapter = adpgol_pangkat

        if(modeEdit) {
            val nid = intent.getStringExtra("nid")
            val nama = intent.getStringExtra("nama")
            val jabatan = intent.getStringExtra("jabatan")
            val golpangkat = intent.getStringExtra("gol_pangkat")
            val pendidikan = intent.getStringExtra("pendidikan")
            val keahlian = intent.getStringExtra("keahlian")
            val programstudi = intent.getStringExtra("program_studi")

            etNidn.setText(nid)
            etNmDosen.setText(nama)
            spnJabatan.setSelection(jabatann.indexOf(jabatan))
            spnGolpangkat.setSelection(gol_pangkat.indexOf(golpangkat))
            if(pendidikan == "S2") rdS2.isChecked = true else rdS3.isChecked = true
            etKeahlian.setText(keahlian)
            etPstudi.setText(programstudi)
        }
        etNidn.isEnabled = !modeEdit

        btnSimpan.setOnClickListener {
            if("${etNidn.text}".isNotEmpty() && "${etNmDosen.text}".isNotEmpty() && "${etKeahlian.text}".isNotEmpty()
                && "${etPstudi.text}".isNotEmpty() && (rdS2.isChecked || rdS3.isChecked)) {
                val db = DbHelper(this@EntriDosenActivity)
                db.nidn = "${etNidn.text}"
                db.nmDosen = "${etNmDosen.text}"
                db.keahlian = "${etKeahlian.text}"
                db.pstudi = "${etPstudi.text}"
                db.jabatan = spnJabatan.selectedItem as String
                db.gol_pangkat = spnGolpangkat.selectedItem as String
                db.pendidikan = if(rdS2.isChecked) "S2" else "S3"
                if(if(!modeEdit) db.simpan() else db.ubah("${etNidn.text}")) {
                    Toast.makeText(
                        this@EntriDosenActivity,
                        "Data Dosen Berhasil Disimpan",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                } else
                    Toast.makeText(
                        this@EntriDosenActivity,
                        "Data Dosen Gagal Disimpan",
                        Toast.LENGTH_SHORT
                    ).show()
            } else
                Toast.makeText(
                    this@EntriDosenActivity,
                    "Data Dosen Belum Lengkap",
                    Toast.LENGTH_SHORT
                ).show()
        }

    }

}